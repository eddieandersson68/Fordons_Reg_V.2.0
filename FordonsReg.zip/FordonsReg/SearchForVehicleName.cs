﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FordonsReg
{
    class SearchForVehicleName
    {
        public static void FindVehicleNames(string searchstring) // Method to search for vehicle names
        {
            /* Takes the parameter called searchstring and checks if it's
            *  value is represented in the 3 different lists. 
            *  If it is */
            
            var quaryCars = from p in Lists.Carlist // Search car list
                            where p.Name.ToLower() == searchstring.ToLower()
                            orderby p.Name
                            select p;


            var queryBoats = from p in Lists.Boatslist  // Search  boat list
                             where p.Name.ToLower() == searchstring.ToLower()
                             orderby p.Name
                             select p;

            var queryMc = from p in Lists.Mclist // Search MC list
                          where p.Name.ToLower() == searchstring.ToLower()
                          orderby p.Name
                          select p;

            Console.Clear();
            Console.WriteLine("Vehicles");
            Console.WriteLine("\n-------------------------------");
            Console.WriteLine("--- Cars---");
            foreach (var item in quaryCars)
            {
                Console.WriteLine(item);
            }

            Console.WriteLine("\n-------------------------------");
            Console.WriteLine("--- Boats---");
            foreach (var item in queryBoats)
            {
                Console.WriteLine(item);
            }

            Console.WriteLine("\n-------------------------------");
            Console.WriteLine("--- Motorcykles---");
            foreach (var item in queryMc)
            {
                Console.WriteLine(item);
            }

            Console.WriteLine("\n-------------------------------");
        }
    }
}
