﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Specialized;

namespace FordonsReg
{
    class Program
    {
        //Programstart
        static void Main(string[] args)
        {
            Console.ForegroundColor = ConsoleColor.Gray;
            //Printar ut prgoramet
            MainMenu.Print();            
            Console.ReadKey();            
        }
    }
}
