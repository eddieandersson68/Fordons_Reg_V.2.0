﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.IO;

namespace FordonsReg
{

    class FirstUserChocie
    {
        //Första userInput och printar ut första varvet listor
        public int Choice { get; set; }
        public FirstUserChocie(int choice)
        {
            switch (choice)
            {
                case 0:
                    {
                        break;
                    }
                case 1:
                    {
                        Car.Print(Lists.Carlist);
                        break;
                    }
                case 2:
                    {
                        Boat.print(Lists.Boatslist);
                        break;
                    }
                case 3:
                    {
                        Motorcykle.print(Lists.Mclist);
                        break;
                    }
                case 4:
                    {
                        Converter.PrintSpeedInMetersPerSecond(Lists.Carlist, Lists.Boatslist, Lists.Mclist);
                        Console.WriteLine("Press any key to continue main");
                        Console.ReadKey();
                        Console.Clear();
                        MainMenu.Print();
                        break;
                    }
                case 5:
                    {
                        Console.WriteLine("Search for vehicle name");
                        string SearchQuery = Console.ReadLine();
                        SearchForVehicleName.FindVehicleNames(SearchQuery);
                        MainMenu.ContinueText();
                        break;
                    }
                case 6:
                    {
                        Environment.Exit(0);
                        break;
                    }
                case 9:
                    {
                        Console.Clear();
                        string dirpath = Directory.GetCurrentDirectory().ToString();
                        string line;
                        StreamReader sr = new StreamReader(dirpath + "\\Dune01_Inv.txt");
                        line = sr.ReadLine();

                        while (line != null)
                        {
                            Thread.Sleep(100);
                            Console.WriteLine(line);
                            line = sr.ReadLine();
                        }
                        sr.Close();
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        string o = "Happy Easter! Press any Key to Exit! ";
                        Console.SetCursorPosition((Console.WindowWidth - o.Length) / 2, Console.CursorTop);
                        Console.WriteLine(o);
                        Console.ResetColor();
                        Console.ReadKey();

                        Environment.Exit(0);
                        break;
                    }
                default:
                    {
                        //Console.WriteLine("\a");
                        MainMenu.NotCorrectNr();
                        break;
                    }
            }
        }

    }
}

