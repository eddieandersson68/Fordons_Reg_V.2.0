﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;


namespace FordonsReg
{
    public class Lists
    {
        public static List<IVehicle> Carlist = new List<IVehicle>();
        public static List<IVehicle> Boatslist = new List<IVehicle>();
        public static List<IVehicle> Mclist = new List<IVehicle>();
    }

    class ProgramHandler
    {


        //Hanterar logiken för att skapa objekt, lägga till i listor samt redigera
        public int userip1 { get; set; }
        public int useramount { get; set; }
        public ProgramHandler(int userip1, int useramount, string editchoice)
        {
            if (editchoice == "i")
            {
                goto edit;
            }
            switch (userip1)
            {
                case 0:
                    {
                        break;
                    }
                case 1:
                    {
                        for (int i = 0; i < useramount; i++)
                        {
                            Lists.Carlist.Add(new Car());
                        }
                        Car.Print(Lists.Carlist);
                        break;
                    }
                case 2:
                    {
                        for (int i = 0; i < useramount; i++)
                        {
                            Lists.Boatslist.Add(new Boat());
                        }
                        Boat.print(Lists.Boatslist);
                        break;
                    }
                case 3:
                    {
                        for (int i = 0; i < useramount; i++)
                        {
                            Lists.Mclist.Add(new Motorcykle());
                        }
                        Motorcykle.print(Lists.Mclist);
                        break;
                    }
            }
            edit:
           
            Console.WriteLine("\nChoose an Index Nr to edit" + " OR " + "press" + " X " + "to go back to main menu ");

            ConsoleKeyInfo keyinfo1 = Console.ReadKey();
            string useranswer2 = keyinfo1.KeyChar.ToString();
            //string useranswer2 = Console.ReadLine();  
            if (useranswer2 == "x")
            {
                goto start;
            }
            int usranswr = int.Parse(useranswer2);


            if (usranswr > Lists.Carlist.Count && usranswr > Lists.Boatslist.Count && usranswr > Lists.Mclist.Count)
            {
                MainMenu.IndexOutOfRange();
            }
         
            Console.WriteLine("\nPress - to remove and + to edit");

            ConsoleKeyInfo keyinfo2 = Console.ReadKey();
            string useranswer = keyinfo2.KeyChar.ToString();


            if (useranswer != "+" && useranswer != "-")
            {
                MainMenu.NotPlusOrMinus();
                goto edit;
            }

            if (useranswer == "-" && userip1 == 1) // Cars chosen
            {
                Console.WriteLine($"\nYou have chosen to remove Car: {usranswr} ");
                Lists.Carlist.RemoveAt(usranswr - 1);
                Car.Print(Lists.Carlist);
                MainMenu.ContinueText();
                Console.ReadKey();
            }
            else if (useranswer == "-" && userip1 == 2) // Boats chosen
            {
                Console.WriteLine($"\nYou have chosen to remove Boat: {usranswr} ");
                Lists.Boatslist.RemoveAt(usranswr - 1);
                Boat.print(Lists.Boatslist);
                MainMenu.ContinueText();
                Console.ReadKey();
            }
            else if (useranswer == "-" && userip1 == 3) // Mc chosen
            {
                Console.WriteLine($"\nYou have chosen to remove Motorcykle: {usranswr} ");
                Lists.Mclist.RemoveAt(usranswr - 1);
                Motorcykle.print(Lists.Mclist);
                MainMenu.ContinueText();
                Console.ReadKey();
            }
                    

            if (useranswer == "+" && userip1 == 1)
            {
                Console.WriteLine($"\nYou have chosen to edit Car: {usranswr} ");
                editSpeed1:
                MainMenu.NewSpeedPrint();
                int newspeed = int.Parse(Console.ReadLine());
                if (newspeed >= 0 && newspeed <= 100)
                {
                    Lists.Carlist[usranswr - 1].setspeed(newspeed);
                    Car.Print(Lists.Carlist);
                }

                else
                {
                    MainMenu.WrongSpeed();
                    goto editSpeed1;
                }
            }
            else if (useranswer == "+" && userip1 == 2)
            {
                Console.WriteLine($"\nYou have chosen to edit Boat: {usranswr} ");
                editSpeed2:
                MainMenu.NewSpeedPrint();
                int newspeed = int.Parse(Console.ReadLine());
                if (newspeed >= 0 && newspeed <= 100)
                {
                    Lists.Boatslist[usranswr - 1].setspeed(newspeed);
                    Boat.print(Lists.Boatslist);
                }
                else
                {
                    MainMenu.WrongSpeed();
                    goto editSpeed2;
                }
            }
            else if (useranswer == "+" && userip1 == 3)
            {
                Console.WriteLine($"\nYou have chosen to edit Motorcykle: {usranswr} ");
                editSpeed3:
                MainMenu.NewSpeedPrint();
                int newspeed = int.Parse(Console.ReadLine());
                if (newspeed >= 0 && newspeed <= 100)
                {
                    Lists.Mclist[usranswr - 1].setspeed(newspeed);
                    Motorcykle.print(Lists.Mclist);
                }
                else
                {
                    MainMenu.WrongSpeed();
                    goto editSpeed3;
                }
            }
            
            start:
            MainMenu.Print();

        }

        
    }
}
