﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace FordonsReg
{
   public class MainMenu
    {
        static void SetConsoleSize()
        {
            System.Console.SetWindowPosition(0, 0);   // sets window position to upper left
            System.Console.SetBufferSize(800, 500);   // make sure buffer is bigger than window
            System.Console.SetWindowSize(500,300);   //set window size to almost full screen 
                                                     //width - maxSet(127,57) (width, height)

            //System.Console.ResetColor(); //resets fore and background colors to default
        }
        
        public static void PrintMenue()
        {
            //Printar ut menyer
            Welcome();
            Console.WriteLine("\n\n-- Please Select --\n");
            Console.WriteLine("1. Print/Create Cars");
            Console.WriteLine("2. Print/Create Boats");
            Console.WriteLine("3. Print/Create Motorcykles");
            Console.WriteLine("4. Print all Vehicles in m/s");
            Console.WriteLine("5. Search for vehicle");
            Console.WriteLine("6. Exit program ");
            Console.WriteLine("7. EasterEgg");
            Console.WriteLine("");
            Console.WriteLine("Please select 1-7, and hit enter");
        }
        public static void Print()
        {
            try
            {
                PrintMenue();
                string userip1 = Console.ReadLine();
                int userconv1 = int.Parse(userip1);
                new FirstUserChocie(userconv1);

                Console.WriteLine("Choose an amount to create or press i to edit and hit enter");

                string userip2 = Console.ReadLine();

                string editchoice = "";
                int userconv2 = 0;
                if (userip2 == "i")
                {
                    editchoice = "i";
                }

                else
                {
                    userconv2 = int.Parse(userip2);
                }
                //int userconv2 = int.Parse(userip2);
                new ProgramHandler(userconv1, userconv2, editchoice);
            }
            catch
            {
                Error();
            }
        }


        public static void NewSpeedPrint() // Just prints what's below
        {
            Console.WriteLine("\nChoose a new speed between 0 - 100: End with enter ");
        }


        public static void WrongSpeed() /* Method to display that the user didn't type a new speed 
                                            in the allowed interval*/
        {
            //Console.WriteLine("\a");
            Console.ForegroundColor = ConsoleColor.Red;
            string n ="that's not between 0-100, try again ";
            Console.SetCursorPosition((Console.WindowWidth - n.Length) / 2, Console.CursorTop);
            
            Console.WriteLine(n);
            Console.ForegroundColor = ConsoleColor.Gray;
        }

        public static void ContinueText()
        {

            string k = "Hit any key to go back to main menu";
            Console.SetCursorPosition((Console.WindowWidth - k.Length) / 2, Console.CursorTop);
            Console.WriteLine(k);
            Console.ReadKey();
            Console.Clear();
            MainMenu.Print();
            //Console.WriteLine("\nHit any key to continue: ");
        }
        public static void Welcome()
        {
            string s = "Welcome to our garage sim";
            Console.SetCursorPosition((Console.WindowWidth - s.Length) / 2, Console.CursorTop);
            Console.WriteLine(s);
        }


       
        public static void Error()
        {
            //Console.WriteLine("\a");
            Console.ForegroundColor = ConsoleColor.Red;
            string e = "An exception occured! Sorry! ";
            Console.SetCursorPosition((Console.WindowWidth - e.Length) / 2, Console.CursorTop);
            Console.WriteLine(e);
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine("Going back to main!");
            Thread.Sleep(1000);
            Console.Clear();
            MainMenu.Print();
        }

        public static void IndexOutOfRange()
        {
            //Console.WriteLine("\a");
            Console.ForegroundColor = ConsoleColor.Red;
            string e = "Error: You've chosen an index that does not exist ";
            Console.SetCursorPosition((Console.WindowWidth - e.Length) / 2, Console.CursorTop);
            Console.WriteLine(e);
            Console.ForegroundColor = ConsoleColor.Gray;
            string f = "Going back to main!";
            Console.SetCursorPosition((Console.WindowWidth - f.Length) / 2, Console.CursorTop);
            Console.WriteLine(f);
            Thread.Sleep(2000);
            Console.Clear();
            MainMenu.Print();
        }


        public static void NotCorrectNr()
        {
            Console.ForegroundColor = ConsoleColor.Red;
            //Console.WriteLine("\a");
            string p = "You typed the wrong key, please select between 1-7 ";
            Console.SetCursorPosition((Console.WindowWidth - p.Length) / 2, Console.CursorTop);
            Console.WriteLine(p);
            Console.ForegroundColor = ConsoleColor.Gray;
            Thread.Sleep(3000);
            Console.Clear();
            MainMenu.Print();

        }public static void NotPlusOrMinus()
        {
            //Console.WriteLine("\a");
            Console.ForegroundColor = ConsoleColor.Red;
            string y = "That's not + OR -, try again";
            Console.SetCursorPosition((Console.WindowWidth - y.Length) / 2, Console.CursorTop);
            Console.WriteLine(y);
            Console.ForegroundColor = ConsoleColor.Gray;
        }

        public static void NotXOrIndex()
        {
            //Console.WriteLine("\a");
            Console.ForegroundColor = ConsoleColor.Red;
            string g = "That's not x OR a valid  Index nr, try again";
            Console.SetCursorPosition((Console.WindowWidth - g.Length) / 2, Console.CursorTop);
            Console.WriteLine(g);
            Console.ForegroundColor = ConsoleColor.Gray;
        }


    }
}
